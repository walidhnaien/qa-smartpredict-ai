package com.qasmartpredict.backend.service.orchestrator;

import java.util.*;
import java.util.concurrent.*;
import jakarta.annotation.PreDestroy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Foundation only: no LLM calls and no real quality report. */
@Service
public class QaOrchestratorService {
    private static final Logger LOG = LoggerFactory.getLogger(QaOrchestratorService.class);
    private final JdbcTemplate db;
    private final TransactionTemplate tx;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    public QaOrchestratorService(JdbcTemplate db, PlatformTransactionManager tm) {
        this.db=db; this.tx=new TransactionTemplate(tm);
    }
    public Map<String,Object> start(UUID releaseId, String mode) {
        if (!"SIMULATION".equals(mode)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"V3.5.1 requires explicit SIMULATION mode");
        if (releaseId==null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"releaseId required");
        UUID id=UUID.randomUUID();
        try {
            tx.executeWithoutResult(s -> {
                if (!Boolean.TRUE.equals(db.queryForObject("SELECT EXISTS(SELECT 1 FROM release WHERE id=?)",Boolean.class,releaseId)))
                    throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Release not found");
                db.update("INSERT INTO ai_workflow_run(id,release_id,workflow_version,mode,status) VALUES (?,?,'V3.5.1','SIMULATION','PENDING')",id,releaseId);
                int order=0;
                for (var step:QaWorkflowPlan.STEPS) db.update("INSERT INTO ai_workflow_step(id,run_id,step_name,step_order,status,model) VALUES (?,?,?,?,'PENDING',?)",UUID.randomUUID(),id,step.name(),++order,step.model());
            });
        } catch (DuplicateKeyException e) { throw new ResponseStatusException(HttpStatus.CONFLICT,"Another workflow is active",e); }
        try { worker.submit(() -> execute(id)); }
        catch (RejectedExecutionException e) { fail(id); throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Worker unavailable",e); }
        return Map.of("runId",id,"status","PENDING","mode","SIMULATION","workflowVersion","V3.5.1","totalSteps",8);
    }
    private void execute(UUID id) {
        try {
            if(db.update("UPDATE ai_workflow_run SET status='RUNNING',started_at=now() WHERE id=? AND status='PENDING'",id)!=1) return;
            for(var step:QaWorkflowPlan.STEPS) {
                tx.executeWithoutResult(s -> {
                    db.update("UPDATE ai_workflow_run SET current_step=? WHERE id=?",step.name(),id);
                    db.update("UPDATE ai_workflow_step SET status='RUNNING',attempt=1,started_at=now() WHERE run_id=? AND step_name=?",id,step.name());
                });
                // Explicit simulation, not a successful agent execution.
                Thread.sleep(750);
                db.update("UPDATE ai_workflow_step SET status='SIMULATED',completed_at=now(),duration_ms=(extract(epoch FROM (now()-started_at))*1000)::bigint WHERE run_id=? AND step_name=?",id,step.name());
            }
            db.update("UPDATE ai_workflow_run SET status='COMPLETED',current_step=NULL,completed_at=now(),duration_ms=(extract(epoch FROM (now()-started_at))*1000)::bigint WHERE id=?",id);
        } catch (Exception e) {
            LOG.error("Workflow {} failed",id,e);
            try { fail(id); } catch (Exception persistenceError) { LOG.error("Cannot persist workflow failure {}",id,persistenceError); }
            if(e instanceof InterruptedException) Thread.currentThread().interrupt();
        }
    }
    private void fail(UUID id) {
        tx.executeWithoutResult(s -> {
            db.update("UPDATE ai_workflow_step SET status='FAILED',completed_at=now(),error_message='Workflow execution interrupted or failed' WHERE run_id=? AND status='RUNNING'",id);
            db.update("UPDATE ai_workflow_step SET status='SKIPPED' WHERE run_id=? AND status='PENDING'",id);
            db.update("UPDATE ai_workflow_run SET status='FAILED',completed_at=now(),error_message='Workflow execution interrupted or failed',duration_ms=(extract(epoch FROM (now()-coalesce(started_at,created_at)))*1000)::bigint WHERE id=? AND status IN ('PENDING','RUNNING')",id);
        });
    }
    public Map<String,Object> get(UUID id) {
        var rows=db.queryForList("SELECT * FROM ai_workflow_run WHERE id=?",id);
        if(rows.isEmpty()) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Workflow not found");
        return rows.get(0);
    }
    public List<Map<String,Object>> steps(UUID id) { get(id); return db.queryForList("SELECT * FROM ai_workflow_step WHERE run_id=? ORDER BY step_order",id); }
    public List<Map<String,Object>> runs() { return db.queryForList("SELECT * FROM ai_workflow_run ORDER BY created_at DESC LIMIT 100"); }
    @PreDestroy public void shutdown() { worker.shutdownNow(); try { worker.awaitTermination(5,TimeUnit.SECONDS); } catch(InterruptedException e) { Thread.currentThread().interrupt(); } }
}
